package com.clazz.inspection;

import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.twelvemonkeys.lang.StringUtil;

import java.util.Stack;

class ClassReferenceUtil {
    static boolean isJdkClass(PsiElement element) {
        if (element == null) {
            return false;
        }
        PsiFile file = element.getContainingFile();
        if (file == null) {
            return false;
        }
        String path = file.getViewProvider().toString();
        return path.contains("/lib/") && (StringUtil.containsIgnoreCase(path, "jre") || StringUtil.containsIgnoreCase(path, "jdk"));
    }
    static String printError(Stack<ClassReference> path) {
        StringBuilder sb = new StringBuilder("Dependency Issue:\n");
        while (!path.isEmpty()) {
            ClassReference importReference = path.pop();
            sb.append(importReference.name).append("\n");
            if (importReference.isSelfShadowed()) {
                for (String container : importReference.containers) {
                    sb.append("\t-->").append(container).append("\n");
                }
            } else if (importReference.isEmpty) {
                sb.append("\t-->").append("not implemented").append("\n");
            }
        }
        return sb.toString();
    }
}

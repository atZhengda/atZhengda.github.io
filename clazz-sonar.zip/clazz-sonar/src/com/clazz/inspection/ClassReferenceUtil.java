package com.clazz.inspection;

import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.twelvemonkeys.lang.StringUtil;

class ClassReferenceUtil {
    static boolean isJdkClass(PsiElement element) {
        if (element == null) {
            return false;
        }
        PsiFile file = element.getContainingFile();
        if (file == null) {
            return false;
        }
        String path = file.getViewProvider().toString();
        return path.contains("/lib/") && (StringUtil.containsIgnoreCase(path, "jre") || StringUtil.containsIgnoreCase(path, "jdk"));
    }
}

package com.clazz.inspection;

import com.intellij.codeInspection.InspectionManager;
import com.intellij.codeInspection.ProblemDescriptor;
import com.intellij.codeInspection.ProblemHighlightType;
import com.intellij.openapi.roots.ProjectFileIndex;
import com.intellij.openapi.roots.libraries.Library;
import com.intellij.openapi.roots.libraries.LibraryUtil;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.*;
import com.intellij.psi.impl.compiled.ClassFileDecompiler;
import com.intellij.psi.impl.compiled.ClsClassImpl;
import com.intellij.psi.impl.source.PsiJavaFileImpl;
import com.intellij.psi.util.ClassUtil;
import com.intellij.util.SmartList;

import java.util.*;

class ClassReferenceProcessor {
    private final HashMap<String, ClassReference> referenceHashMap = new HashMap<>();
    private final HashMap<Library, Integer> libraries = new HashMap<>();
    private final ProjectFileIndex fileIndex;
    private final PsiManager manager;
    private ClassFileDecompiler decompiler = new ClassFileDecompiler();

    ClassReferenceProcessor(ProjectFileIndex fileIndex, PsiManager manager) {
        this.fileIndex = fileIndex;
        this.manager = manager;
    }

    void updateLib(Library library) {
        if (libraries.containsKey(library)) {
            libraries.put(library, 0);
        } else {
            libraries.put(library, 1);// new library
        }
    }

    void syncLib() {
        boolean needSync = libraries.containsValue(-1) || libraries.containsValue(1);
        if (needSync) {
            libraries.values().remove(-1); // remove expired values;
            referenceHashMap.clear();// clear all state if libraries has changed
            System.err.println("library has changed, clear internal state");
        }
        libraries.replaceAll((l, i) -> -1);// set all values to -1 for next round check up
    }

    private boolean shouldProcess(ClassReference reference) {
        return (!reference.isCompleted) || System.currentTimeMillis() - reference.lastProcessed > 60 * 1000;
    }

    private void linkFileDependency(ClassReference classReference, PsiElement file) {
        System.out.println("linking[src] " + file.getContainingFile().getName());
        classReference.dependsOn.clear();
        file.getContainingFile().acceptChildren(new JavaRecursiveElementVisitor() {
            @Override
            public void visitImportList(PsiImportList element) {
                PsiImportStatementBase[] imports = element.getAllImportStatements();
                for (PsiImportStatementBase importStatementBase : imports) {
                    PsiJavaCodeReferenceElement reference = importStatementBase.getImportReference();
                    if (reference != null) {
                        // link up
                        ClassReference next = referenceHashMap.computeIfAbsent(reference.getQualifiedName(), ClassReference::new);
                        System.out.println("<--" + next.name);
                        next.referenceElement = reference;
                        classReference.dependsOn.add(next);
                    }
                }
            }
        });
    }

    private void linkClassFileDependency(ClassReference classReference, PsiElement file) {
        PsiFile containingFile1 = file.getContainingFile();
        System.out.println("linking[cls] " + containingFile1.getName());
        classReference.dependsOn.clear();
        String content = decompiler.decompile(containingFile1.getVirtualFile()).toString();
        String[] lines = content.split("\n");
        for (String line : lines) {
            if (line.startsWith("import ")) {
                String qualifiedName = line.replaceAll("import |;", "").trim();
                ClassReference next = referenceHashMap.computeIfAbsent(qualifiedName, ClassReference::new);
                System.out.println("<--" + next.name);
                classReference.dependsOn.add(next);
            }
        }
    }


    private void processClassFileRecursively(final ClassReference classReference, PsiElement element, Set<String> visited) {
        visited.add(classReference.name);

        if (!shouldProcess(classReference)) {
            System.out.println("not processing " + classReference.name);
            return;
        }
        boolean jdkClass = ClassReferenceUtil.isJdkClass(element);
        if (element == null || jdkClass) {
            // no element found, empty implementation
            classReference.lastProcessed = Long.MAX_VALUE;
            classReference.isEmpty = !jdkClass;
            classReference.isCompleted = true;
            return;
        }

        PsiFile containingFile = element.getContainingFile();
        classReference.containers.clear();
        // check for multiple implementations
        libraries.keySet().forEach(library -> {
            if (LibraryUtil.isClassAvailableInLibrary(library, classReference.name)) {
                classReference.containers.add(library.getName());
            }
        });
        if (fileIndex.isInSource(containingFile.getVirtualFile())) {
            classReference.containers.add(containingFile.getName());
        }
        if (classReference.containers.isEmpty()) {
            //inner class
            classReference.containers.add(element.getContainingFile().getName());
        }

        int totalImplementation = classReference.containers.size();
        classReference.isEmpty = false;
        // shadowed
        if (totalImplementation > 1) {
            classReference.isCompleted = true;
            classReference.lastProcessed = Long.MAX_VALUE;
            return;
        }
        // empty implementation
        if (totalImplementation < 1) {
            classReference.isCompleted = true;
            classReference.lastProcessed = Long.MAX_VALUE;
            classReference.isEmpty = true;
            return;
        }

        boolean linked = false;
        if (fileIndex.isInSource(containingFile.getVirtualFile())) {
            // source code
            linkFileDependency(classReference, element);
            classReference.lastProcessed = System.currentTimeMillis();
            linked = true;
        } else if (element instanceof ClsClassImpl) {
            PsiClass sourceClass = ((ClsClassImpl) element).getSourceMirrorClass();
            if (sourceClass != null) {
                // library source code
                linkFileDependency(classReference, sourceClass);
                classReference.lastProcessed = System.currentTimeMillis();
                linked = true;
            }
        }
        if (!linked) {
            //decompile and link
            linkClassFileDependency(classReference, element);
        }
        classReference.isCompleted = true;
        for (ClassReference dependency : classReference.dependsOn) {
            if (!visited.contains(dependency.name)) {
                PsiElement depEle = null;
                if (dependency.referenceElement != null) {
                    depEle = dependency.referenceElement.resolve();
                }
                if (depEle == null) {
                    depEle = ClassUtil.findPsiClass(manager, dependency.name);
                }
                processClassFileRecursively(dependency, depEle, visited);
            }
        }
    }

    ProblemDescriptor[] lintFile(InspectionManager inspectionManager, PsiFile file, boolean isOnTheFly) {
        if (!(file instanceof PsiJavaFileImpl)) {
            return null;
        }
        String fileName = ((PsiJavaFileImpl) file).getPackageName() + "." + file.getName();
        fileName = fileName.replace(".java", "");
        ClassReference reference = referenceHashMap.computeIfAbsent(fileName, ClassReference::new);
        if(reference.lastProcessed==Long.MAX_VALUE){
            reference.lastProcessed=System.currentTimeMillis();
        }

        final Set<String> buildingVisited = new HashSet<>();// for dependency building
        processClassFileRecursively(reference, file, buildingVisited);

        //return cache result if available
        if (System.currentTimeMillis() - reference.lastVisited < 60 * 1000) {
            return reference.problemDescriptors;
        }

        final List<ProblemDescriptor> descriptors = new SmartList<>();
        final Set<String> checkingVisited = new HashSet<>();// for dependency checking
        file.getContainingFile().acceptChildren(new JavaRecursiveElementVisitor() {
            @Override
            public void visitImportList(PsiImportList element) {

                for (PsiImportStatementBase importStatementBaseElement : element.getAllImportStatements()) {
                    PsiJavaCodeReferenceElement javaCodeReferenceElement = importStatementBaseElement.getImportReference();
                    if (javaCodeReferenceElement != null) {
                        String name = javaCodeReferenceElement.getQualifiedName();
                        ClassReference importReferenceLine = referenceHashMap.get(name);
                        if (importReferenceLine != null) {
                            Stack<ClassReference> path = new Stack<>();
                            if (walkDependencies(importReferenceLine, checkingVisited, path)) {
                                ProblemDescriptor problemDescriptor = inspectionManager.createProblemDescriptor(importStatementBaseElement, (TextRange) null, printError(path), ProblemHighlightType.GENERIC_ERROR_OR_WARNING, isOnTheFly, new RemoveImport());

                                descriptors.add(problemDescriptor);

                            }
                        }
                    }
                }
            }
        });
        ProblemDescriptor[] problemDescriptors = descriptors.toArray(new ProblemDescriptor[0]);
        reference.lastVisited = System.currentTimeMillis();
        reference.problemDescriptors = problemDescriptors;
        return problemDescriptors;
    }

    private String printError(Stack<ClassReference> path) {
        StringBuilder sb = new StringBuilder("Dependency Issue:\n");
        while (!path.isEmpty()) {
            ClassReference importReference = path.pop();
            sb.append(importReference.name).append("\n");
            if (importReference.isSelfShadowed()) {
                for (String container : importReference.containers) {
                    sb.append("\t-->").append(container).append("\n");
                }
            } else if (importReference.isEmpty) {
                sb.append("\t-->").append("not implemented").append("\n");
            }
        }
        return sb.toString();
    }

    private boolean walkDependencies(ClassReference importReference, Set<String> visited, Stack<ClassReference> path) {
        //depth first conflict class walker, exits at first error
        String className = importReference.name;
        if (visited.contains(className)) {
            return false;
        }

        if (importReference.isSelfShadowed() || importReference.isEmpty) {
            path.add(importReference);
            return true;
        }
        visited.add(className);
        for (ClassReference dependency : importReference.dependsOn) {
            if (walkDependencies(dependency, visited, path)) {
                path.add(importReference);
                return true;
            }
        }
        return false;

    }
}

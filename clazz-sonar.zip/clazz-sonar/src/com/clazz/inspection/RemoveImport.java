package com.clazz.inspection;

import com.intellij.codeInspection.LocalQuickFix;
import com.intellij.codeInspection.ProblemDescriptor;
import com.intellij.openapi.editor.Document;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.PsiDocumentManager;
import com.intellij.psi.PsiElement;
import org.jetbrains.annotations.NotNull;

class RemoveImport implements LocalQuickFix {

    @NotNull
    public String getFamilyName() {
        return "Remove conflict Class import";
    }

    public void applyFix(@NotNull Project project, @NotNull ProblemDescriptor descriptor) {
        PsiElement element = descriptor.getPsiElement();
        TextRange docRange = element.getTextRange();
        Document document = PsiDocumentManager.getInstance(project).getDocument(element.getContainingFile());
        if(document!=null){
            document.deleteString(docRange.getStartOffset(), docRange.getEndOffset());
        }
    }
}
package com.clazz.inspection;

import com.intellij.codeInspection.ProblemDescriptor;
import com.intellij.psi.PsiJavaCodeReferenceElement;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class ClassReference {
    final String name;
    boolean isCompleted;
    long lastProcessed;
    Set<ClassReference> dependsOn = new HashSet<>();
    Set<String> containers = new HashSet<>();
    boolean isEmpty;// no implementation of class
    PsiJavaCodeReferenceElement referenceElement;
    ProblemDescriptor[] problemDescriptors;
    long lastVisited;

    ClassReference(String name) {
        this.name = name;
    }

    boolean isSelfShadowed() {
        return containers.size() > 1;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClassReference that = (ClassReference) o;
        return Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}

package com.clazz.inspection;

import com.intellij.codeInspection.InspectionManager;
import com.intellij.codeInspection.LocalInspectionTool;
import com.intellij.codeInspection.ProblemDescriptor;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtil;
import com.intellij.openapi.roots.ModuleRootManager;
import com.intellij.openapi.roots.ProjectFileIndex;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.psi.PsiFile;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;

public class ClassImportInspection extends LocalInspectionTool {
    private HashMap<Module, ClassReferenceProcessor> processorHashMap=new HashMap<>();

    @Override
    public String getStaticDescription() {
        return "Problematic class imports";
    }

    @Nullable
    @Override
    public ProblemDescriptor[] checkFile(@NotNull PsiFile file, @NotNull InspectionManager manager, boolean isOnTheFly) {
        try {
            Module moduleForFile = ModuleUtil.findModuleForFile(file);
            ClassReferenceProcessor processor = processorHashMap.computeIfAbsent(moduleForFile, module -> {
                ProjectFileIndex fileIndex = ProjectRootManager.getInstance(file.getProject()).getFileIndex();
                return new ClassReferenceProcessor(fileIndex, file.getManager());
            });
            if (moduleForFile != null) {
                ModuleRootManager.getInstance(moduleForFile).orderEntries().forEachLibrary(library -> {
                    processor.updateLib(library);
                    return true;
                });
                processor.syncLib();
            }
            return processor.lintFile(manager, file, isOnTheFly);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


}

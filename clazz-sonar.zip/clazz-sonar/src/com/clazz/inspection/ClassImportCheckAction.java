package com.clazz.inspection;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.CommonDataKeys;
import com.intellij.openapi.actionSystem.LangDataKeys;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtil;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ModuleRootManager;
import com.intellij.openapi.roots.ProjectFileIndex;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.openapi.ui.Messages;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiManager;
import org.jetbrains.annotations.NotNull;

import java.util.Collection;
import java.util.HashMap;
import java.util.Stack;

class ClassImportCheckAction extends AnAction {
    private HashMap<Module, ClassReferenceProcessor> processorHashMap = new HashMap<>();

    @Override
    public void update(@NotNull final AnActionEvent anActionEvent) {
        final Project project = anActionEvent.getData(CommonDataKeys.PROJECT);
        final Editor editor = anActionEvent.getData(CommonDataKeys.EDITOR);
        anActionEvent.getPresentation().setVisible((project != null && editor != null && editor.getCaretModel().getCaretCount() > 0));
    }

    @Override
    public void actionPerformed(AnActionEvent anActionEvent) {
        PsiFile file = anActionEvent.getData(LangDataKeys.PSI_FILE);
        Project project = anActionEvent.getProject();
        if (file == null || project == null) {
            return;
        }

        Module moduleForFile = ModuleUtil.findModuleForFile(file);
        ClassReferenceProcessor processor = processorHashMap.computeIfAbsent(moduleForFile, module -> {
            ProjectFileIndex fileIndex = ProjectRootManager.getInstance(project).getFileIndex();
            PsiManager psiManager = file.getManager();
            return new ClassReferenceProcessor(fileIndex, psiManager);
        });
        if (moduleForFile != null) {
            ModuleRootManager.getInstance(moduleForFile).orderEntries().forEachLibrary(library -> {
                processor.updateLib(library);
                return true;
            });
            processor.syncLib();
        }
        Collection<Stack<ClassReference>> stacks = processor.lintFile(file);
        if (stacks == null) {
            Messages.showMessageDialog(project, "No problem found", "Imports Are OK", Messages.getInformationIcon());
        } else {
            StringBuilder sb = new StringBuilder();
            for (Stack<ClassReference> stack : stacks) {
                sb.append(ClassReferenceUtil.printError(stack)).append("\n");
            }
            Messages.showMessageDialog(project, sb.toString(), stacks.size() + " Problem(s) Found", Messages.getInformationIcon());
        }
    }
}
